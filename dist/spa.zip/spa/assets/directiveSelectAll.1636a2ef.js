var l={mounted(t){const e=t.querySelector("input");e.addEventListener("focus",()=>{e.value.length&&e.select()})}};export{l as v};
